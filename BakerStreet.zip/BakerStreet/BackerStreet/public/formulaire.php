<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $telephone = $_POST["telephone"];
    $email = $_POST["email"];
    $code_postal = $_POST["code_postal"];
    $ville = $_POST["ville"];
    $message = $_POST["message"];
    $accepter = isset($_POST["accepter"]) ? "Oui" : "Non";

    $destinataire = "walid.boumlid@gmail.com";
    $sujet = "Nouveau formulaire de contact";
    $corps_message = "Nom: $nom\n";
    $corps_message .= "Prenom: $prenom\n";
    $corps_message .= "Téléphone: $telephone\n";
    $corps_message .= "Adresse e-mail: $email\n";
    $corps_message .= "Code postal: $code_postal\n";
    $corps_message .= "Ville: $ville\n";
    $corps_message .= "Message:\n$message\n";
    $corps_message .= "Accepté la clause de consentement: $accepter";

    // Envoi de l'e-mail
    mail($destinataire, $sujet, $corps_message);

    // Redirection vers une page de confirmation
    header("Location: confirmation.html");
}
?>