const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 3000; // Choisissez le port que vous souhaitez utiliser

// Middleware pour traiter les données JSON
app.use(bodyParser.json());

// Connexion à la base de données (remplacez 'URL_DE_VOTRE_BASE_DE_DONNEES' par votre URL MongoDB)
mongoose.connect('URL_DE_VOTRE_BASE_DE_DONNEES', { useNewUrlParser: true, useUnifiedTopology: true });

// Schema MongoDB pour les utilisateurs
const userSchema = new mongoose.Schema({
  username: String,
  password: String
});

const User = mongoose.model('User', userSchema);

// Endpoint pour la page de connexion
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  // Vérifier les informations de connexion dans la base de données
  const user = await User.findOne({ username, password });

  if (user) {
    res.json({ success: true, message: 'Connexion réussie' });
  } else {
    res.json({ success: false, message: 'Échec de la connexion' });
  }
});

// Démarrer le serveur
app.listen(port, () => {
  console.log(`Serveur en cours d'exécution sur le port ${port}`);
});
