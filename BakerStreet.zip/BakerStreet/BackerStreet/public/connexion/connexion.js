const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 3000; // Choisissez le port que vous souhaitez utiliser

// Middleware pour traiter les données JSON
app.use(bodyParser.json());

// Connexion à la base de données
mongoose.connect('mongodb+srv://WalidB:azert006.9@cluster0.kfpel4a.mongodb.net/Connexion?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });

// Schema MongoDB pour les utilisateurs
const userSchema = new mongoose.Schema({
  login: {
    type: String,
    required: true,
    trim: true
  },
  password: {
    type: String,
    required: true,
    trim: true
  }
});

const User = mongoose.model('Utilisateurs', userSchema);

app.get('/', (req, res) => {
  res.sendFile(path.join("../accueil.html"));
});

app.get('/u', async (req, res) => {
  const user = await User.find() /* User.find()*/;
  res.status(200).send(user);
});

app.post('/user', async (req, res) => {
  let user = new User ();
  const { login, password } = req.body;
  user.login = login;
  user.password = password;
  user.save();
  res.status(200).send("OK");
});

// Endpoint pour la page de connexion
app.post('/login', async (req, res) => {
  const { login, password } = req.body;

  // Vérifier les informations de connexion dans la base de données
  const user = await User.findOne({ login, password });

  if (user) {
    res.json({ success: true, message: 'Connexion réussie' });
  } else {
    res.json({ success: false, message: 'Échec de la connexion' });
  }
});

// Démarrer le serveur
app.listen(port, () => {
  console.log(`Serveur en cours d'exécution sur le port ${port}`);
});
