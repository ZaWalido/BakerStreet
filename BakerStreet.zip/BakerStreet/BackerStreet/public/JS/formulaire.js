document.addEventListener("DOMContentLoaded", function() {
    const contactForm = document.getElementById("contactForm");
    const consentForm = document.getElementById("consentForm");

    contactForm.addEventListener("submit", function(event) {
        // Vous pouvez ajouter ici la logique de validation du formulaire de contact.
        // Si des erreurs sont détectées, vous pouvez empêcher l'envoi du formulaire en utilisant event.preventDefault().

        // Exemple de validation de champ (à personnaliser) :
        const nomInput = document.getElementById("nom");
        if (nomInput.value.trim() === "") {
            event.preventDefault(); // Empêche l'envoi du formulaire
            alert("obligatoire.");
        }

        // Vous pouvez ajouter des validations supplémentaires pour les autres champs ici.

        // Si le formulaire est valide, il sera soumis normalement.
    });

    consentForm.addEventListener("submit", function(event) {
        // Validation du formulaire de consentement (cocher la case).
        const accepterCheckbox = document.getElementById("accepter");
        if (!accepterCheckbox.checked) {
            event.preventDefault(); // Empêche l'envoi du formulaire
            alert("Vous devez cocher la case pour accepter");
        }
    });
});