document.addEventListener("DOMContentLoaded", function() {

    var addProduct = function(name, description, price) {
        const xhr = new XMLHttpRequest();
        let params = "name=" + name + "&description=" + description + "&price=" + price;
        xhr.open("POST", "http://localhost:3000/product");
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = () => {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                location.reload();
            }
            else { //Le ELSE c'est si la requete a pas fonctionner
                console.log(xhr.status);
            }
        };
        xhr.send(params);
    };
    
    var deleteProduct = function(id) {
        const xhr = new XMLHttpRequest();
        xhr.open("DELETE", "http://localhost:3000/product/"+id);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = () => {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                location.reload();
            }
            else { //Le ELSE c'est si la requete a pas fonctionner
                console.log(xhr.status);
            }
        };
        xhr.send();
    };
    
    var updateProduct = function(id, name, description, price) {
        const xhr = new XMLHttpRequest();
        let params = "name=" + name + "&description=" + description + "&price=" + price;
        xhr.open("PUT", "http://localhost:3000/product/"+id);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = () => {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                location.reload();
            }
            else { //Le ELSE c'est si la requete a pas fonctionner
                console.log(xhr.status);
            }
        };
        xhr.send(params);
    };
    
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "http://localhost:3000/product"); //requete GET vers le serveur qui pioche dans la base de donnée
    xhr.send();
    xhr.responseType = "json";
    xhr.onload = () => { //Fonction qui s'éxécute après la requete
        if (xhr.readyState == 4 && xhr.status == 200) { //le IF se lance si la requete a fonctionner
            xhr.response.forEach((product) => { //xhr.response correspond au résultat de la requete get //forEach c'est une boucle
                document.getElementById('products').innerHTML += "<a class=\"boites\"><div class=\"box\"><div class=\"contenu\"><button id=\""+product._id+"\" class=\"deletebutton\">X</button><h2>"+product.name+"<br><span>"+product.description+"</span></h2></div></div></a>";
            });
            console.log(xhr.response);

            const buttons = document.querySelectorAll('.deletebutton');
            console.log(buttons);
            
            buttons.forEach((b) => {
                b.addEventListener("click", function() {
                    deleteProduct(this.id);
                });
            });
        } else { //Le ELSE c'est si la requete a pas fonctionner
            console.log(xhr.status);
        }
    };

    const buttonAdd = document.querySelector("#buttonAddProduct");
    buttonAdd.addEventListener("click", function() {
        let name = document.getElementById("formName").value;
        let description = document.getElementById("formDescription").value;
        let price = document.getElementById("formPrice").value;
        formAddProduct(name, description, price);
    });
    var formAddProduct = function(name, description, price) {
        addProduct(name, description, price);
    };


}); // Faut plus rien écrire a partir d'ici
