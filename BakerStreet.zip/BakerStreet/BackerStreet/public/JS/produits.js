const xhr = new XMLHttpRequest();
xhr.open("GET", "http://localhost:3000/product"); //requete GET vers le serveur qui pioche dans la base de donnée
xhr.send();
xhr.responseType = "json";
xhr.onload = () => { //Fonction qui s'éxécute après la requete
    if (xhr.readyState == 4 && xhr.status == 200) { //le IF se lance si la requete a fonctionner
        xhr.response.forEach((product) => { //xhr.response correspond au résultat de la requete get //forEach c'est une boucle
            document.getElementById('products').innerHTML += "<a href=\"\" class=\"boites\"><div class=\"box\"><div class=\"contenu\"><h2>"+product.name+"<br><span>"+product.description+"</span></h2></div></div></a>";
        });
        console.log(xhr.response);
    } else { //Le ELSE c'est si la requete a pas fonctionner
        console.log(xhr.status);
    }
};

