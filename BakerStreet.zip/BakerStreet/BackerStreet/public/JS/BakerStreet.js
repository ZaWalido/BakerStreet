const transition = document.querySelector(".transition");
setTimeout(function () {
    transition.classList.remove("active");
}, 400);

// on sélectionne les liens de pages qui joueront l'animation
const liens = document.querySelectorAll('nav a');

for (let i = 0; i < liens.length; i++) {
    let lien = liens[i];

    // on écoute le clic sur ces liens
    lien.addEventListener('click', function (event) {
        //on empêche le lien de nous diriger vers une autre page

        // connaitre sur quel lien a été cliqué
        let lienclic = event.target.href;

        //on ajoute alors la classe "active" pour ajouter le fondu au noir
        transition.classList.add('active');

        //On attend un peu que l'animation se joue et on dirige vers le lien 
        setTimeout(function () {
            window.location.href = lienclic;
        }, 400);
    });
}