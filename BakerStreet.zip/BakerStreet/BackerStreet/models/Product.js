const mongoose = require('mongoose');

// Schema MongoDB pour les produits
const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true,
        trim: true
    },
    price: {
        type: Number,
        required: true,
        trim: true
    }
});

const Product = mongoose.model('produits', productSchema);
module.exports = Product;